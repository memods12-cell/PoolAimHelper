package com.example.poolaimhelper

import android.app.Service
import android.content.Intent
import android.graphics.*
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class AimOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: AimView? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val angle = intent?.getFloatExtra("angle", 0f) ?: 0f
        val length = intent?.getFloatExtra("length", .72f) ?: .72f
        val banks = intent?.getBooleanExtra("banks", false) ?: false
        val collision = intent?.getBooleanExtra("collision", false) ?: false
        if (overlay == null) {
            overlay = AimView(this)
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            wm.addView(overlay, params)
        }
        overlay?.configure(angle, length, banks, collision)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        overlay?.let { wm.removeView(it) }
        overlay = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

private class AimView(context: android.content.Context) : View(context) {
    private val main = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW; strokeWidth = 5f; style = Paint.Style.STROKE
    }
    private val guide = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.CYAN; strokeWidth = 3f; style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private var angle = 0f
    private var length = .72f
    private var banks = false
    private var collision = false

    fun configure(a: Float, l: Float, b: Boolean, c: Boolean) {
        angle = a; length = l; banks = b; collision = c; invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radians = Math.toRadians(angle.toDouble())
        val dx = (width * length / 2f * kotlin.math.cos(radians)).toFloat()
        val dy = (width * length / 2f * kotlin.math.sin(radians)).toFloat()
        canvas.drawLine(cx - dx, cy - dy, cx + dx, cy + dy, main)
        canvas.drawCircle(cx, cy, 9f, main)

        if (banks) {
            // Reference geometry only; not a physics solver.
            canvas.drawLine(0f, cy - height * .22f, width.toFloat(), cy + height * .22f, guide)
            canvas.drawLine(0f, cy + height * .22f, width.toFloat(), cy - height * .22f, guide)
        }
        if (collision) {
            canvas.drawLine(cx, cy, cx + dx * .55f, cy + dy * .55f, guide)
            canvas.drawLine(cx, cy, cx - dy * .45f, cy + dx * .45f, guide)
        }
    }
}
