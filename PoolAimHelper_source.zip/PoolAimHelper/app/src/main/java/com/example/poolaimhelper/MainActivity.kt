package com.example.poolaimhelper

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private var angle = 0f
    private var length = 0.72f
    private var banks = false
    private var collision = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(20, 25, 32))
        }
        fun label(s: String) = TextView(this).apply {
            text = s; textSize = 16f; setTextColor(Color.WHITE); setPadding(8, 12, 8, 12)
        }
        fun button(s: String, action: () -> Unit) = Button(this).apply {
            text = s; setOnClickListener { action() }
        }

        layout.addView(label("POOL AIM HELPER\nEkran üstü yardımcı çizgiler"))
        layout.addView(label("Bu araç topu otomatik algılamaz; çizgileri elle hizalaman gerekir."))
        layout.addView(button("Kaplamayı başlat") { startOverlay() })
        layout.addView(button("Açıyı sola çevir") { angle -= 5f; updateOverlay() })
        layout.addView(button("Açıyı sağa çevir") { angle += 5f; updateOverlay() })
        layout.addView(button("Çizgiyi uzat") { length = (length + .08f).coerceAtMost(1f); updateOverlay() })
        layout.addView(button("Çizgiyi kısalt") { length = (length - .08f).coerceAtLeast(.2f); updateOverlay() })
        layout.addView(button("Bant kılavuzunu aç/kapat") { banks = !banks; updateOverlay() })
        layout.addView(button("Çarpışma yönü kılavuzunu aç/kapat") { collision = !collision; updateOverlay() })
        layout.addView(button("Kaplamayı kapat") { stopService(Intent(this, AimOverlayService::class.java)) })
        setContentView(layout)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }
        updateOverlay()
    }

    private fun updateOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        val i = Intent(this, AimOverlayService::class.java).apply {
            putExtra("angle", angle); putExtra("length", length)
            putExtra("banks", banks); putExtra("collision", collision)
        }
        startService(i)
    }
}
